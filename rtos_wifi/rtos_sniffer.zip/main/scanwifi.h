#ifndef __SCANWIFI_H
#define __SCANWIFI_H
#include "esp_wifi.h"
#include "esp_system.h"
#include "esp_event.h"
#include "esp_event_loop.h"
#include "esp_log.h"
#include "driver/uart.h"
#include "string.h"
extern void wifiscan(void);
void keepinfo();

#define TAG "sniffer"
#ifndef MAC2STR
#define MAC2STR(a) (a)[0], (a)[1], (a)[2], (a)[3], (a)[4], (a)[5]
#define MACSTR "%02X:%02X:%02X:%02X:%02X:%02X"
#endif
 void 
writeSniffDataToFlash(char* data );

#include "spi_flash.h"
#endif